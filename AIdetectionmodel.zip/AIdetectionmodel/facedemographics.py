import tkinter as tk
from tkinter import *
from tkinter import scrolledtext, filedialog, ttk
import os
import subprocess

def check_and_popup():
    action_log.config(state=tk.NORMAL)
    action_log.insert(END, f"Opening Advanced Settings\n")
    action_log.config(state=tk.DISABLED)
    selected_value = v.get()
    if selected_value == 1:
        face_popup = tk.Toplevel(root)
        face_popup.title("Advanced Settings")
        face_popup.geometry("200x200")

        def close_face():
            action_log.config(state=tk.NORMAL)
            action_log.insert(END, f"Closing Advanced Settings\n")
            action_log.config(state=tk.DISABLED)
            face_popup.destroy()

        # Popup Window Buttons
        brightenButton = tk.Button(face_popup, text="Brighten", width=10, command=lambda: run_brighten(get_selected_folder(), output_path))
        brightenButton.pack(pady=5)
    
        flipButton = tk.Button(face_popup, text="Flip", width=10, command=lambda: run_flip(get_selected_folder(), output_path))
        flipButton.pack(pady=5)

        close_button = tk.Button(face_popup, text="Close", width=10, command=close_face)
        close_button.pack(pady=5)
    elif selected_value == 2:
        others_popup = tk.Toplevel(root)
        others_popup.title("Advanced Settings")
        others_popup.geometry("200x200")
        
        def close_others():
            action_log.config(state=tk.NORMAL)
            action_log.insert(END, f"Closing Advanced Settings\n")
            action_log.config(state=tk.DISABLED)
            others_popup.destroy()

        othersLabel = tk.Label(others_popup, text="Other Features Coming Soon!")
        othersLabel.pack(pady=5)

        close_button = tk.Button(others_popup, text="Close", width=10, command=close_others)
        close_button.pack(pady=5)
    else:
        invalid_popup = tk.Toplevel(root)
        invalid_popup.title("Error")
        invalid_popup.geometry("200x80")

        invalidLabel = tk.Label(invalid_popup, text="Please select a valid option")
        invalidLabel.pack(pady=5)

        def close_invalid():
            action_log.config(state=tk.NORMAL)
            action_log.insert(END, f"Closing Advanced Settings\n")
            action_log.config(state=tk.DISABLED)
            invalid_popup.destroy()

        close_button = tk.Button(invalid_popup, text="Close", width=10, command=close_invalid)
        close_button.pack(pady=5)

def start_task(task_name):
    progress['value'] = 10
    main_frame.update_idletasks()
    action_log.config(state=tk.NORMAL)
    action_log.insert(END, f"Starting {task_name}\n")
    action_log.config(state=tk.DISABLED)

def mid_task(task_name):
    progress['value'] = 50
    main_frame.update_idletasks()

def done_task(task_name):
    progress['value'] = 100
    main_frame.update_idletasks()
    action_log.config(state=tk.NORMAL)
    action_log.insert(END, f"Finished {task_name}\n")
    action_log.config(state=tk.DISABLED)


def run_brighten(input_folder, output_folder):
    if input_folder and output_folder:
        script_path = os.path.abspath("AIdetectionmodel/brighten.py")
        try:
            subprocess.run(["python", script_path, input_folder, output_folder], check=True)
            print("Brighten script ran successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error running brighten.py: {e}")
    else:
        print("No folder selected or output path specified for brighten operation.")

def run_flip(input_folder, output_folder):
    if input_folder and output_folder:
        script_path = os.path.abspath("AIdetectionmodel/horizontalFlip.py")
        try:
            subprocess.run(["python", script_path, input_folder, output_folder], check=True)
            print("Flip script ran successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error running horizontalFlip.py: {e}")
    else:
        print("No folder selected or output path specified for flip operation.")

def add_folder():
    folder_path = filedialog.askdirectory()
    if folder_path:
        if folder_path not in folders:
            folders.append(folder_path)
            folder_name = os.path.basename(folder_path)
            action_log.config(state=tk.NORMAL)
            action_log.insert(END, f"{folder_name}, has been added\n")
            action_log.config(state=tk.DISABLED)
        update_folder_listbox()
        update_button_states()

def remove_folder():
    selected_folder_index = folder_listbox.curselection()
    if selected_folder_index:
        folder_path = folders[selected_folder_index[0]]
        folders.remove(folder_path)
        folder_name = os.path.basename(folder_path)
        action_log.config(state=tk.NORMAL)
        action_log.insert(END, f"{folder_name}, has been removed\n")
        action_log.config(state=tk.DISABLED)
        update_folder_listbox()
        update_button_states()

def update_folder_listbox():
    folder_listbox.delete(0, END)
    for folder_path in folders:
        folder_listbox.insert(END, os.path.basename(folder_path))

def update_button_states():
    has_files = len(folders) > 0
    removeFolderButton.config(state=NORMAL if has_files else DISABLED)
    trainButton.config(state=NORMAL if has_files else DISABLED)
    testButton.config(state=NORMAL if has_files else DISABLED)
    predictButton.config(state=NORMAL if has_files else DISABLED)
    settingsButton.config(state=NORMAL if has_files else DISABLED)

def get_selected_folder():
    selected_folder_index = folder_listbox.curselection()
    if selected_folder_index:
        return folders[selected_folder_index[0]]
    return None

def select_output_folder():
    global output_path
    output_path = filedialog.askdirectory()
    if output_path:
        outputPathLabel.config(text=f"Output Path: {output_path}")

# Create Main Window
root = tk.Tk()
root.title("AI Detection Model")
root.geometry("300x700")  # Window Size in pixels

main_frame = tk.Frame(root, padx=5, pady=10)
main_frame.pack(expand=True, fill='both')

# Create Label
SelectionLabel = tk.Label(main_frame, text="Select Desired AI Feature")
SelectionLabel.pack(anchor=W)

# Create Radio Button
v = IntVar()
v.set(1)
faceRadiobutton = tk.Radiobutton(main_frame, text='Face Demographics', variable=v, value=1).pack(anchor=W)
othersRadiobutton = tk.Radiobutton(main_frame, text='Others', variable=v, value=2).pack(anchor=W)
othersRadiobutton = tk.Radiobutton(main_frame, text='Not This One', variable=v, value=3).pack(anchor=W)

# Create Listbox for Folders
folders = []
folder_listbox = tk.Listbox(main_frame, height=6, selectmode=SINGLE)
folder_listbox.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
folder_listbox.bind('<<ListboxSelect>>', lambda event: update_button_states())

# Create Button Frame
button_frame = tk.Frame(main_frame)
button_frame.pack(pady=5)

# Create Buttons
addFolderButton = tk.Button(button_frame, text="Add Folder", width=12, command=add_folder)
addFolderButton.pack(side=LEFT, padx=5)

removeFolderButton = tk.Button(button_frame, text="Remove Folder", width=15, command=remove_folder, state=DISABLED)
removeFolderButton.pack(side=LEFT, padx=5)

trainButton = tk.Button(main_frame, text="Train Model", width=15, state=DISABLED)  # command=train_model
trainButton.pack(pady=5)

testButton = tk.Button(main_frame, text="Test Model", width=15, state=DISABLED)  # command=test_model
testButton.pack(pady=5)

predictButton = tk.Button(main_frame, text="Predict Existing", width=15, state=DISABLED)  # command=predict_existing
predictButton.pack(pady=5)

settingsButton = tk.Button(main_frame, text="Advanced Settings", width=15, state=DISABLED, command=check_and_popup)
settingsButton.pack(pady=5)

# Output Path Selection
outputPathButton = tk.Button(main_frame, text="Select Output Path", width=15, command=select_output_folder)
outputPathButton.pack(pady=5)

outputPathLabelFrame = tk.Frame(main_frame)
outputPathLabelFrame.pack(pady=5, padx=5, fill=tk.BOTH, expand=True)

outputPathLabel = tk.Label(outputPathLabelFrame, text="Output Path: Not Selected", wraplength=280, justify=LEFT)
outputPathLabel.pack()

#Create Progress Bar
progress = ttk.Progressbar(main_frame, orient="horizontal", length=300, mode="determinate")
progress.pack(padx=10, pady=10)

# Create Action Log
action_log = scrolledtext.ScrolledText(main_frame, wrap=tk.WORD, height=10, state='disabled')
action_log.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

# Create Footer
footer_frame = tk.Frame(root, height=30)
footer_frame.pack(side=tk.BOTTOM, fill=tk.X)

footer_label = tk.Label(footer_frame, text="FootfallCam", anchor=tk.W)
footer_label2 = tk.Label(footer_frame, text="Version 1.0.0", anchor=tk.E)

footer_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
footer_label2.grid(row=0, column=1, padx=5, pady=5, sticky=tk.E)

footer_frame.columnconfigure(0, weight=1)
footer_frame.columnconfigure(1, weight=1)

# Initial button state update
update_button_states()

# Start Event Loop
root.mainloop()
