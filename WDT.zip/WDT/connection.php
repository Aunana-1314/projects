<?php

$host="localhost";
$user="root";
$password="";
$database="login_db";

$con=mysqli_connect($host, $user, $password,$database);
if (mysqli_connect_errno()) {
echo "Failed to connect";
exit();
}

?>