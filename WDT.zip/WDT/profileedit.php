<?php
session_start();
?>
<html>

<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/navbar.css">
  <link rel="stylesheet" href="css/profileedit.css">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Profile</title>
</head>

<body>
  <header class="header">
    <nav class="navbar">
      <h2 class="logo"><a href="#">DeliverBee <img src="img/logo.png" alt="logo"></a></h2>
      <label for="menu-toggle" id="hamburger-btn">
      </label>
      <ul class="links">
        <li><a onclick="location.href='customerhome.php';">Home</a></li>
        <li><a onclick="location.href='feedback.php';">Feedback</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Services
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="#">Delivery Tracking</a>
            <a class="dropdown-item" onclick="location.href='customerhome.php';">Tracking Page</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Orders
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" onclick="location.href='previousorder.php';">Previous Orders</a>
            <a class="dropdown-item" onclick="location.href='pendingorder.php';">Pending Orders</a>
          </div>
        </li>
      </ul>
    </nav>
  </header>


  <div class="edit-profile-page">
    <h1 class="beeg">Edit Profile</h1>
    <form action="databasestuff.php" method="POST" class="edit-profile-form">
      <div class="form-group">
        <label for="newProfilePicture" class="laybel">Profile Picture</label>
        <input type="file" id="newProfilePicture" name="newProfilePicture" accept="image/*" style="display:none">
        <p></p>
        <div>
          <label for="newProfilePicture" class="labelbutton">Select File</label>
        </div>
      </div>
      <div class="form-group">
        <label for="newPhoneNumber" class="laybel">Phone Number</label>
        <input type="text" id="newPhoneNumber" name="newPhoneNumber" placeholder="Enter new phone number">
      </div>
      <div class="form-group">
        <label for="newEmail" class="laybel">Email</label>
        <input type="email" id="newEmail" name="newEmail" placeholder="Enter new email">
      </div>
      <div class="form-group">
        <label for="newAddress" class="laybel">Address</label>
        <textarea id="newAddress" name="newAddress" placeholder="Enter new address"></textarea>
      </div>
      <div class="action">
        <button type="submit" class="save-button">Save Changes</button>
      </div>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>