<?php
session_start();

$host="localhost";
$user="root";
$password="";
$database="login_db";

$mysqli = new mysqli($host, $user, $password, $database);

$user_name = $_SESSION["user_name"];
$stmt = $mysqli->query("SELECT id FROM users WHERE user_name = '$user_name'");
$result = $stmt->fetch_all();
$id = $result[0][0];

$details = [];

$sql = "";
$phone_num = $_POST["newPhoneNumber"];
$email = $_POST["newEmail"];
$address = $_POST["newAddress"];

if (strlen($email) != 0 ) {
    $details += ["email" => $email];
}

if (strlen($phone_num) != 0 ) {
    $details += ["phone_num" => $phone_num];
}

if (strlen($address) != 0 ) {
    $details += ["address" => $address];
}

$sql = "UPDATE users SET";
$len = sizeof($details);
$count = 0;
foreach ($details as $key => $value) {
    if ($key == "email" || $key == "phone_num" || $key == "address") {
        $sql = "$sql $key = '$value'";
    }

    if ($count != $len - 1) {
        $sql = "$sql, ";
    } 

    $count++;
}

$mysqli->query("$sql WHERE id=$id;");

header("location: profile.php");