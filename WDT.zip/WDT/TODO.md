# General
- [ ] Add checks for unset variables in session storage. Checks are needed at (non exhaustive)
    - `profile.php`
- URLs/buttons that don't work
    - [ ] Delivery Tracking
    - [ ] Orders button
        - It doesn't work after you go into any of the pages. The dropdown doesn't show up.

# Profile page
# 