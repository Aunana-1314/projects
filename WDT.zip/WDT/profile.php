<?php
session_start();

$host="localhost";
$user="root";
$password="";
$database="login_db";
$user_name = $_SESSION["user_name"];


$mysqli = new mysqli($host, $user, $password, $database);

$sql = "SELECT * FROM users WHERE user_name = '$user_name'";


$result = $mysqli->query($sql);
$result = $result->fetch_all(MYSQLI_ASSOC);

$result = $result[0];

$profile_image = $result["profile_image"];
$phone_num = $result["phone_num"];
$email = $result["email"];
$address = $result["address"];

?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/navbar.css">
        <link rel="stylesheet" href="css/profile.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Profile</title>
    </head>
    <body>
    <header class="header">
      <nav class="navbar">
        <h2 class="logo"><a href="#">DeliverBee <img src="img/logo.png" alt="logo"></a></h2>
        <label for="menu-toggle" id="hamburger-btn">
        </label>
        <ul class="links">
          <li><a onclick="location.href='customerhome.php';">Home</a></li>
          <li><a onclick="location.href='feedback.php';">Feedback</a></li>
          <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Services
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" onclick="location.href='customerhome.php#search';">Delivery Tracking</a>
          <a class="dropdown-item" onclick="location.href='trackingpage.php';">Tracking Page</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Orders
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" onclick="location.href='previousorder.php';">Previous Orders</a>
          <a class="dropdown-item" onclick="location.href='pendingorder.php';">Pending Orders</a>
        </div>
      </li>
        </ul>
        <?php echo "
        <div class='buttons'>
          <a onclick=\"location.href='logout.php';\" class='login'>Logout</a>
        </div>";
        ?>
      </nav>
    </header>
    <?php
            echo "
    <div class='profile-menu'>
          <div class='profile-container'>
            <div class='profile-picture'>
                <img src='$profile_image' alt='Profile Picture'>
            </div>
            
            <h1 class='username'>$user_name</h1>
          
            <div class='profile-slab'>
              <p class='phone' id='phoneNumber'>Phone: $phone_num</p>
            </div>
            <div class='profile-slab'>
              <p class='email' id='email'>Email: $email</p>
            </div>
            <div class='profile-slab'>
              <p class='address' id='address'>Address: $address</p>
            </div>";
          ?>
            <a onclick="location.href='profileedit.php';" class="edit-profile-button">Edit Profile</a>
          </div>
        </div>

        <!-- <script>
          document.addEventListener('DOMContentLoaded', function () {
              const phoneNumber = localStorage.getItem('phoneNumber');
              const email = localStorage.getItem('email');
              const address = localStorage.getItem('address');
              
              if (phoneNumber) {
                  document.getElementById('phoneNumber').textContent = `Phone: ${phoneNumber}`;
              }
              if (email) {
                  document.getElementById('email').textContent = `Email: ${email}`;
              }
              if (address) {
                  document.getElementById('address').textContent = `Address: ${address}`;
              }
          });
      </script> -->


        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>
</html>