<?php
session_start();
  include('connection.php');
  include('functions.php');

  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
    $user_name = $_POST['name'];
    $topic = $_POST['topic'];
    $feedback = $_POST['description'];

    if(!empty($user_name) && !empty($topic) && !empty($feedback))
    {
      $query = "INSERT into feedbacks (user_name, topic, feedback) values ('$user_name','$topic','$feedback')";

      if (!mysqli_query($con,$query)){
        die('Error!'.mysqli_error($con));
      }
      else {
      echo"<script>alert('Feedback submitted successfully!');
      window.location='customerhome.php'</script>";
      }
  }else 
  {
  echo $query;
  }
}

  ?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/navbar.css">
        <link rel="stylesheet" href="css/feedbody.css">
        <title>Feedback</title>
    </head>
    <body>
        <header class="header">
            <nav class="navbar">
              <h2 class="logo"><a href="#">DeliverBee <img src="img/logo.png" alt="logo"></a></h2>

              </label>
              <ul class="links">
                <li><a onclick="location.href='customerhome.php';">Home</a></li>
                <li><a onclick="location.href='feedback.php';">Feedback</a></li>
                <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Services
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" onclick="location.href='customerhome.php#search';">Delivery Tracking</a>
                <a class="dropdown-item" onclick="location.href='trackingpage.php';">Tracking Page</a>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Orders
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" onclick="location.href='previousorder.php';">Previous Orders</a>
                <a class="dropdown-item" onclick="location.href='pendingorder.php';">Pending Orders</a>
              </div>
            </li>
              </ul>
            
            </nav>
          </header>

          <div class="container">
            <h1 class="balls">Feedback</h1>
            <form method="post">
                <div class="form-group">
                    <label for="topic" class="balls">Topic:</label>
                    <input type="text" placeholder="Enter your point of discussion" id="topic" name="topic" required>
                </div>
                <div class="form-group">
                    <label for="name" class="balls">Name:</label>
                    <input type="text" placeholder="Enter your name" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="description" class="balls">Description:</label>
                    <textarea id="description" placeholder="Provide a detailed version of your feedback here" name="description" required></textarea>
                </div>
                <div class="action">
                    <button type="submit">Submit</button>
                </div>
            </form>
        </div>
        





        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>
</html>