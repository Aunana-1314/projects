<?php
session_start();
  include('connection.php');
  include('functions.php');

  if(isset($_POST['loginbtn'])){
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];
    $_SESSION["user_name"] = $user_name;
    $query = "SELECT * FROM users WHERE user_name='$user_name' AND password ='$password'";
    $results = mysqli_query($con, $query);
 
    if(mysqli_num_rows($results) > 0){
       $row = mysqli_fetch_array($results);
 
       if(isset($row['role'])){
          if($row['role'] == 'admin'){
             $_SESSION['user_name'] = $row['user_name'];
             header("Location: adminhome.php");
          } elseif($row['role'] == 'customer'){
             $_SESSION['user_name'] = $row['user_name'];
             header("Location: customerhome.php");
          }
       } else  
        {
          echo"<script>alert('User type not found');
          window.location='login.php'</script>";
       }
    } else 
      {
        echo"<script>alert('User not found');
        window.location='login.php'</script>";
    }
    mysqli_close($connection);
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login to DeliverBee</title>
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Rubik:400,700'><link rel="stylesheet" href="css/login.css">
</head>
<body>
<!-- partial:index.partial.html -->
<div class="login-form">
  <form method="post">
    <h1>Login <img src="img/logo.png" alt="logo"></h1>
    
    <div class="content">
      <div class="input-field">
        <input type="username" name="user_name" placeholder="Username" autocomplete="nope">
      </div>
      <div class="input-field">
        <input type="password" name="password" placeholder="Password" autocomplete="new-password">
      </div>
      <a href="#" class="link">Forgot Your Password?</a>
    </div>
    <div class="action">
      <button type="button" onclick="location.href='register.php';">Register</button>
      <button type="submit" name="loginbtn">Login</button>
    </div>
  </form>
</div>
<!-- partial -->
  <script  src="./script.js"></script>
</html>