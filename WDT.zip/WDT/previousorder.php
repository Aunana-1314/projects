<?php
session_start();

$host="localhost";
$user="root";
$password="";
$database="login_db";
$user_name = $_SESSION["user_name"];

$mysqli = new mysqli($host, $user, $password, $database);

$sql = "SELECT * FROM orders WHERE cust_name='$user_name'AND del_status='Delivered' ";

$result = $mysqli->query($sql);
$results = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Orders</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" href="css/orders.css">
</head>
<body>
<header class="header">
            <nav class="navbar">
              <h2 class="logo"><a href="#">DeliverBee <img src="img/logo.png" alt="logo"></a></h2>

              </label>
              <ul class="links">
                <li><a onclick="location.href='customerhome.php';">Home</a></li>
                <li><a onclick="location.href='feedback.php';">Feedback</a></li>
                <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Services
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" onclick="location.href='customerhome.php#search';">Delivery Tracking</a>
                <a class="dropdown-item" onclick="location.href='trackingpage.php';">Tracking Page</a>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Orders
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" onclick="location.href='previousorder.php';">Previous Orders</a>
                <a class="dropdown-item" onclick="location.href='pendingorder.php';">Pending Orders</a>
              </div>
            </li>
              </ul>
              <div class="buttons">
          <a onclick="location.href='logout.php';" class="login">Logout</a>
        </div>
            </nav>
          </header>

    <?php
                    foreach($results as $result) {

                      $tracking_id = $result["tracking_id"];
                      $cou_name = $result["cou_name"];
                      $address = $result["cust_address"];
                      $item_name = $result["item_name"];
                      $item_image =$result['item_image'];
                      $date = $result["date"];
                      $del_status = $result["del_status"];
                      echo "
<div class='row'>
    <div class='col-lg-8 mx-auto'>

      <!-- List group-->
      <ul class='list-group shadow'>

        <!-- list group item-->
        <li class='list-group-item'>
          <!-- Custom content-->
          <div class='media align-items-lg-center flex-column flex-lg-row p-3'>
            <div class='media-body order-2 order-lg-1'>
              <h5 class='mt-0 font-weight-bold mb-2'>Order Number: $tracking_id</h5>
              <p class='font-italic text-muted mb-0 small'>
            Tracking Number: $tracking_id</br>
            Address: $address </br>
            Item Name: $item_name</br>
            Courier Name: $cou_name</br>
            Date: $date</br>
            </p>
              <div class='d-flex align-items-center justify-content-between mt-1'>
                <h6 class='font-weight-bold my-2'>$del_status</h6>
              </div>
            </div><img src='$item_image' alt='Generic placeholder image' width='200' class='ml-lg-5 order-1 order-lg-2'>
          </div>
          <!-- End -->
        </li>
        <!-- End -->
    </div>
  </div>";
  }
  ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>