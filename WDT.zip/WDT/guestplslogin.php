<?php
session_start();
  $_SESSION;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>god help me</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="header">
      <nav class="navbar">
        <h2 class="logo"><a href="#">DeliverBee <img src="img/logo.png" alt="logo"></a></h2>
        <label for="menu-toggle" id="hamburger-btn">
        </label>
        <ul class="links">
          <li><a onclick="location.href='index.php';">Home</a></li>
          <li><a onclick="location.href='guestplslogin.php';">Feedback</a></li>
          <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Services
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" onclick="location.href='index.php#search';">Delivery Tracking</a>
          <a class="dropdown-item" onclick="location.href='guestplslogin.php';">Tracking Page</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Orders
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" onclick="location.href='guestplslogin.php';">Previous Orders</a>
          <a class="dropdown-item" onclick="location.href='guestplslogin.php';">Pending Orders</a>
        </div>
      </li>
        </ul>
        <div class="buttons">
          <a onclick="location.href='login.php';" class="login">Login</a>
        </div>
      </nav>
    </header>
    <section class="hero-section">
      <div class="hero">
        <h2>You have encountered an error</h2>
        <p>
          <strong>Want to access this page?</strong></br>
        </p>

        <div class="buttons">
          <a onclick="location.href='register.php';" class="join">Sign In Now</a>
        </div>
      </div>
      <div class="img">
        <img src="img/sadbee.png" alt="hero-image" width="500px">
      </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>