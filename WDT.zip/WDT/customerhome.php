<?php
session_start();
 include('connection.php');
 include('functions.php');
$host="localhost";
$user="root";
$password="";
$database="login_db";
$user_name = $_SESSION["user_name"];


$mysqli = new mysqli($host, $user, $password, $database);

$sql = "SELECT * FROM users WHERE user_name = '$user_name'";

$result = mysqli_query($con,$sql);
$result = $result->fetch_all(MYSQLI_ASSOC);

$result = $result[0];

$profile_image = $result["profile_image"];
$phone_num = $result["phone_num"];
$email = $result["email"];
$address = $result["address"];

if ($mysqli->connect_error) {
  die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $userInput = isset($_POST["tracking_id"]) ? intval($_POST["tracking_id"]) : null;

  // change 'tracking_numbers' into the table u want
  $query = "SELECT * FROM orders WHERE tracking_id = ?";
  $stmt = $mysqli->prepare($query);
  $stmt->bind_param("i", $userInput);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows > 0) {
      // change "pepega.php" to the tracking page url
      header("Location: delivery.php");
      exit();
  } else {
      $errorMessage = "Invalid input. Please enter a valid tracking number.";
  }

  $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>god help me</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="header">
      <nav class="navbar">
        <h2 class="logo"><a href="#">DeliverBee <img src="img/logo.png" alt="logo"></a></h2>
        <label for="menu-toggle" id="hamburger-btn">
        </label>
        <ul class="links">
          <li><a onclick="location.href='customerhome.php';">Home</a></li>
          <li><a onclick="location.href='feedback.php';">Feedback</a></li>
          <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Services
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#search">Delivery Tracking</a>
          <a class="dropdown-item" onclick="location.href='trackingpage.php';">Tracking Page</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Orders
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" onclick="location.href='previousorder.php';">Previous Orders</a>
          <a class="dropdown-item" onclick="location.href='pendingorder.php';">Pending Orders</a>
        </div>
      </li>
        </ul>
        <?php echo "
        <div class='buttons'>
          <a onclick=\"location.href='logout.php';\" class='login'>Logout</a>
          <a onclick=\"location.href='profile.php';\"> <img src='$profile_image'></a>
        </div>";
        ?>
      </nav>
    </header>
    <div class="background-image">
      <img src="img/mapbg3.jpg" class="img-fluid">
</div>
    <div class="box">
      <form method="post" class="form-group">
        <label for="ExampleTrackingNumber" style="color:white; font-size:20px">Track your order now</label></br>
        <input type="search" id="search" name="tracking_id" placeholder="Type your tracking number here" size="100px" >
    </form>
  </div>
    <section class="hero-section">
      <div class="hero">
        <h2>What do we offer?</h2>
        <p>
          <strong>Delivery Tracking</strong></br>
          Track your deliveries by using a tracking ID or courier name.
        </p>
        <p>
          <strong>Tracking Page</strong></br>
          A page to list all your items currently being tracked.
        </p>
      </div>
      <div class="img">
        <img src="img/deliveryservice.webp" alt="hero-image" width="500px">
      </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
  </body>
</html>