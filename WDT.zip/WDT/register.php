<?php
session_start();
  include('connection.php');
  include('functions.php');

  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
    {
      $query = "insert into users (user_name, password, email) values ('$user_name','$password','$email')";

      mysqli_query($con,$query);

      echo"<script>alert('Registration Successful!');
      window.location='login.php'</script>";
    }else 
    {
      echo $query;
    }
  }
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register with DeliverBee</title>
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Rubik:400,700'>
    <link rel="stylesheet" href="css/register.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="login-form">
  <form method="post">
    <h1>Register <img src="img/logo.png" alt="logo"></h1>
    
    <div class="content">
      <div class="input-field">
        <input type="text" name="user_name" placeholder="Enter your username">
      </div>
      <div class="input-field">
        <input type="email" name="email" placeholder="Enter your email">
      </div>
      <div class="input-field">
        <input type="password" name="password" placeholder="Enter your password">
      </div>
      <div class="input-field">
        <input type="password" placeholder="Confirm your password">
      </div>
    </div>
    <div class="action">
      <button type="submit">Register Now</button>
    </div>
    <div class="text">
        <h3>Already have an account? <a href="login.php">Login now</a></h3>
      </div>
  </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>