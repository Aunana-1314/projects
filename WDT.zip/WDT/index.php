<?php
session_start();
 include('connection.php');
 include('functions.php');
$host="localhost";
$user="root";
$password="";
$database="login_db";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $userInput = isset($_POST["tracking_id"]) ? intval($_POST["tracking_id"]) : null;

  // change 'tracking_numbers' into the table u want
  $query = "SELECT * FROM orders WHERE tracking_id = ?";
  $stmt = $mysqli->prepare($query);
  $stmt->bind_param("i", $userInput);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows > 0) {
      // change "pepega.php" to the tracking page url
      header("Location: delivery.php");
      exit();
  } else {
      $errorMessage = "Invalid input. Please enter a valid tracking number.";
  }

  $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>god help me</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="header">
      <nav class="navbar">
        <h2 class="logo"><a href="#">DeliverBee <img src="img/logo.png" alt="logo"></a></h2>
        <label for="menu-toggle" id="hamburger-btn">
        </label>
        <ul class="links">
          <li><a onclick="location.href='index.php';">Home</a></li>
          <li><a onclick="location.href='guestplslogin.php';">Feedback</a></li>
          <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Services
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#search">Delivery Tracking</a>
          <a class="dropdown-item" onclick="location.href='guestplslogin.php';">Tracking Page</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Orders
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" onclick="location.href='guestplslogin.php';">Previous Orders</a>
          <a class="dropdown-item" onclick="location.href='guestplslogin.php';">Pending Orders</a>
        </div>
      </li>
        </ul>
        <div class="buttons">
          <a onclick="location.href='login.php';" class="login">Login</a>
        </div>
      </nav>
    </header>
    <div class="background-image">
      <img src="img/mapbg3.jpg" class="img-fluid">
</div>
    <div class="box">
      <form method="post" class="form-group">
        <label for="ExampleTrackingNumber" style="color:white; font-size:20px">Track your order now</label></br>
        <input type="search" id="search" placeholder="Type your tracking number here" size="100px" >
    </form>
  </div>
    <section class="hero-section">
      <div class="hero">
        <h2>What do we offer?</h2>
        <p>
          <strong>Delivery Tracking</strong></br>
          Track your deliveries by using a tracking ID or courier name.
        </p>
        <p>
          <strong>Tracking Page</strong></br>
          A page to list all your items currently being tracked.
        </p>
        <div class="buttons">
          <a onclick="location.href='register.php';" class="join">Sign Up Now</a>
        </div>
      </div>
      <div class="img">
        <img src="img/deliveryservice.webp" alt="hero-image" width="500px">
      </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>