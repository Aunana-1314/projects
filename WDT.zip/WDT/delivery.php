<?php
session_start();

$host="localhost";
$user="root";
$password="";
$database="login_db";
$user_name = $_SESSION["user_name"];


$mysqli = new mysqli($host, $user, $password, $database);

$sql = "SELECT * FROM users WHERE user_name = '$user_name'";


$result = $mysqli->query($sql);
$result = $result->fetch_all(MYSQLI_ASSOC);

$result = $result[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/tracking.css">
    <link rel="stylesheet" type="text/css" href="css/navbar.css">
    <title>Document</title>
</head>
<body>
<header class="header">
      <nav class="navbar">
        <h2 class="logo"><a href="#">DeliverBee <img src="img/logo.png" alt="logo"></a></h2>
        <label for="menu-toggle" id="hamburger-btn">
        </label>
        <ul class="links">
          <li><a onclick="location.href='customerhome.php';">Home</a></li>
          <li><a onclick="location.href='feedback.php';">Feedback</a></li>
          <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Services
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Delivery Tracking</a>
          <a class="dropdown-item" onclick="location.href='trackingpage.php';">Tracking Page</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Orders
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" onclick="location.href='previousorder.php';">Previous Orders</a>
          <a class="dropdown-item" onclick="location.href='pendingorder.php';">Pending Orders</a>
        </div>
      </li>
        </ul>
        <?php echo "
        <div class='buttons'>
          <a onclick=\"location.href='logout.php';\" class='login'>Logout</a>
        </div>";
        ?>
      </nav>
    </header>
<div class="col-md12- mt-1">
    <div class="container">
        <div class="card mb-3 content">
        <h3>Order Tracking</h3>
        <table class="table table-bordered track_tbl">
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Distibutor</th>
                    <th>Date</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <tr class="active">
                    <td class="track_dot">
                        <span class="track_line"></span>
                    </td>
                    <td>Order placed</td>
                    <td>Seller</td>
                    <td>1/11/2023 22:55</td>
                </tr>
                <tr>
                    <td class="track_dot">
                        <span class="track_line"></span>
                    </td>
                    <td>Preparing to ship [China] Seller is preparing to ship your order.</td>
                    <td>Seller</td>
                    <td>2/11/2023 06:24</td>
                </tr>
                <tr>
                    <td class="track_dot">
                        <span class="track_line"></span>
                    </td>
                    <td>Order is shipped.</td>
                    <td>Seller</td>
                    <td>2/11/2023 18:46</td>
                </tr>
                <tr>
                    <td class="track_dot">
                        <span class="track_line"></span>
                    </td>
                    <td>Your parcel has arrived at sorting facility.</td>
                    <td>Poslaju</td>
                    <td>17/11/2023 12:50</td>
                </tr>
                <tr>
                    <td class="track_dot">
                        <span class="track_line"></span>
                    </td>
                    <td>Your parcel has departed from sorting facility</td>
                    <td>Poslaju</td>
                    <td>17/11/2023 14:16</td>
                </tr>
                <tr>
                    <td class="track_dot">
                        <span class="track_line"></span>
                    </td>
                    <td>Your parcel has arrived at the delivery hub [serdang hub]</td>
                    <td>Poslaju</td>
                    <td>19/11/2023 07:37</td>
                </tr>
                <tr>
                    <td class="track_dot">
                        <span class="track_line"></span>
                    </td>
                    <td>Your parcel is out for delivery hub</td>
                    <td>Poslaju</td>
                    <td>20/11/2023 16:57</td>
                </tr>

                <tr>
                    <td class='track_dot'>
                        <span class='track_line'></span>
                    </td>
                    <td><?php echo "Parcel delivered [Recipient name: $user_name]";?></td>
                    <td>Poslaju</td>
                    <td>21/11/2023 10:29</td>
                </tr>
            </tbody>
        </table>
        <a href="customerhome.php">
                <label class="btn btn-primary">Return to homepage</label>
                </a>
            </button>
        </div>
    </div>
</div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>